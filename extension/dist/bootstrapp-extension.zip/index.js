/**
 * @bootstrapp/extension
 * Chrome extension for bidirectional admin panel communication
 */

export { createExtensionBridge, default } from "./admin-bridge.js";
